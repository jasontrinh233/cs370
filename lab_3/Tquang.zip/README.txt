CS370-Lab3:
	Michale Gutierrez
	Quang Trinh

Michale Guiterrez: Built Sequence_Detector_Part (Part 1)
		   Built Programmable User Code (Part 2) 
		   Built 16-bit Lock (Part 1)
                   Test 8-bit Sequencer (Part 2)
	
Quang Trinh: Debugged and rebuilt Sequence Detector Part (Part 1)
	     Built 3 push buttons (Button0, Button1, Reset) mechanisim (Part 1)
	     Built 8-bit Sequencer (Part 2)
	     Test 16-bit Lock (Part 1)
	     Test Programmable User Code (Part 2)

Together: Built Main Circuit for Part 1
	  Built Main Circuit for Part 2

Note: Part 1 secret code is: 10011101 (Michale Gutierrez's REDID)